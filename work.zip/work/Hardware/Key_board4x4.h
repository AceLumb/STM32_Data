#ifndef __MATRIX_KEY_H
#define __MATRIX_KEY_H

#include "stm32f10x.h"
#include <stdbool.h>

// 按键位置结构体
typedef struct {
    uint8_t row;   // 行号(0-3)
    uint8_t col;   // 列号(0-3)
    bool valid;    // 是否有效按键
} KeyPosition;

// 函数声明
void MatrixKey_Init(void);
KeyPosition MatrixKey_Scan(void);

#endif