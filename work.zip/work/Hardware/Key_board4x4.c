#include "stm32f10x.h"
#include <stdbool.h>

// 矩阵键盘引脚定义
#define ROW0_PIN    GPIO_Pin_0
#define ROW1_PIN    GPIO_Pin_1
#define ROW2_PIN    GPIO_Pin_2
#define ROW3_PIN    GPIO_Pin_3
#define ROW_PORT    GPIOA

#define COL0_PIN    GPIO_Pin_4
#define COL1_PIN    GPIO_Pin_5
#define COL2_PIN    GPIO_Pin_6
#define COL3_PIN    GPIO_Pin_7
#define COL_PORT    GPIOA

// 按键位置结构体
typedef struct {
    uint8_t row;   // 行号(0-3)
    uint8_t col;   // 列号(0-3)
    bool valid;    // 是否有效按键
} KeyPosition;

// 初始化矩阵键盘GPIO
void MatrixKey_Init(void) {
    GPIO_InitTypeDef GPIO_InitStructure;
    
    // 使能GPIOA时钟
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    
    // 配置行线(PA0~PA3)为上拉输入
    GPIO_InitStructure.GPIO_Pin = ROW0_PIN | ROW1_PIN | ROW2_PIN | ROW3_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(ROW_PORT, &GPIO_InitStructure);
    
    // 配置列线(PA4~PA7)为推挽输出，初始高电平
    GPIO_InitStructure.GPIO_Pin = COL0_PIN | COL1_PIN | COL2_PIN | COL3_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(COL_PORT, &GPIO_InitStructure);
    
    // 初始时所有列线输出高电平
    GPIO_SetBits(COL_PORT, COL0_PIN | COL1_PIN | COL2_PIN | COL3_PIN);
}

// 扫描按键，返回按键位置（无按键时valid为false）
KeyPosition MatrixKey_Scan(void) {
    KeyPosition pos = {0, 0, false};
    uint8_t row, col;
    
    // 逐列扫描
    for(col = 0; col < 4; col++) {
        // 选中当前列(输出低电平)
        GPIO_SetBits(COL_PORT, COL0_PIN | COL1_PIN | COL2_PIN | COL3_PIN);
        GPIO_ResetBits(COL_PORT, (uint16_t)(1 << col));
        
        // 延时消抖
        for(volatile int i = 0; i < 1000; i++);
        
        // 检测行线状态
        for(row = 0; row < 4; row++) {
            if(GPIO_ReadInputDataBit(ROW_PORT, (uint16_t)(1 << row)) == 0) {
                // 确认按下(消抖)
                for(volatile int i = 0; i < 20000; i++);
                if(GPIO_ReadInputDataBit(ROW_PORT, (uint16_t)(1 << row)) == 0) {
                    // 等待按键释放
                    while(GPIO_ReadInputDataBit(ROW_PORT, (uint16_t)(1 << row)) == 0);
                    
                    // 记录有效按键位置
                    pos.row = row;
                    pos.col = col;
                    pos.valid = true;
                    
                    // 恢复列线高电平
                    GPIO_SetBits(COL_PORT, COL0_PIN | COL1_PIN | COL2_PIN | COL3_PIN);
                    return pos;
                }
            }
        }
        
        // 恢复当前列高电平
        GPIO_SetBits(COL_PORT, COL0_PIN | COL1_PIN | COL2_PIN | COL3_PIN);
    }
    
    return pos;  // 无按键按下
}
