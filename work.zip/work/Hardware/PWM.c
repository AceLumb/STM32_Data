#include "stm32f10x.h"                  // Device header

void PWM_Init(void)
{
	//开启时钟
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);
	//配置GPIO
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;	//采用复用推挽输出模式，让引脚的控制权给到外设，推挽输出的控制权在输出数据寄存器。
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1|GPIO_Pin_0;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	//配置TIM时基单元
	TIM_InternalClockConfig(TIM2);
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;			//内部时钟分频模式
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up; 	//上升沿触发计数
	TIM_TimeBaseInitStructure.TIM_Period = 20000-1;						//ARR
	TIM_TimeBaseInitStructure.TIM_Prescaler = 72-1;					//PSC预分频器
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;				//重复计数器，高级计数器才有
	TIM_TimeBaseInit(TIM2,&TIM_TimeBaseInitStructure);
	//初始化通用比较单元
	TIM_OCInitTypeDef TIM_OCInitStructure;
	TIM_OCStructInit(&TIM_OCInitStructure);							//先统一赋初始值，后面二次赋值需要的
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;	 			//设置比较模式
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;		//设置比较极性
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; 	//设置输出使能
	TIM_OCInitStructure.TIM_Pulse = 0;								//设置CCR比较寄存器
	TIM_OC1Init(TIM2,&TIM_OCInitStructure);	
	TIM_OC2Init(TIM2,&TIM_OCInitStructure);							//多通道设置时频率保持一致，CCR可调

	//使能定时器
	TIM_Cmd(TIM2,ENABLE);

}


void PWM_SetCompare1(uint16_t Compare)
{
	TIM_SetCompare1(TIM2,Compare);
}
void PWM_SetCompare2(uint16_t Compare)
{
	TIM_SetCompare2(TIM2,Compare);
}