#include "stm32f10x.h"
#include "OLED.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

// 按键位置结构体
typedef struct {
    uint8_t row;   // 行号(0-3)
    uint8_t col;   // 列号(0-3)
    bool valid;    // 是否有效按键
} KeyPosition;

// 计算器状态结构体
typedef struct {
    float num1;             // 第一个操作数
    float num2;             // 第二个操作数
    char op;                // 操作符(+, -, *, /, %, //)
    bool op_set;            // 是否已设置操作符
    bool result_displayed;  // 是否显示结果
    char display[20];       // 显示缓冲区
    uint8_t display_pos;    // 显示位置
} CalculatorState;

// 外部函数声明（矩阵键盘驱动）
extern void MatrixKey_Init(void);
extern KeyPosition MatrixKey_Scan(void);

// 函数声明
void Calculator_Init(CalculatorState* state);
void Process_Key(CalculatorState* state, KeyPosition key);
void Process_Number(CalculatorState* state, uint8_t number);
void Process_Operator(CalculatorState* state, char op);
void Calculate(CalculatorState* state);
void Backspace(CalculatorState* state);
void Update_OLED_Display(CalculatorState* state);
void Delay_ms(uint32_t ms);

// 4x4键盘按键映射表（根据实际按键布局调整）
// 行0-3，列0-3对应关系
const char key_map[4][4] = {
    {'7', '8', '9', '/'},    // 行0：7 8 9 /
    {'4', '5', '6', '*'},    // 行1：4 5 6 *
    {'1', '2', '3', '-'},    // 行2：1 2 3 -
    {'C', '0', '=', '+'}     // 行3：C(清除) 0 = +
};

// 额外功能键定义（通过组合键实现）
#define KEY_BACKSPACE '<'    // 退格键
#define KEY_MOD '%'          // 取余键
#define KEY_DIV '\\'         // 整除键（用单斜杠表示，实际显示为//）

// 初始化计算器状态
void Calculator_Init(CalculatorState* state) {
    state->num1 = 0;
    state->num2 = 0;
    state->op = '\0';
    state->op_set = false;
    state->result_displayed = false;
    memset(state->display, 0, sizeof(state->display));
    state->display_pos = 0;
    Update_OLED_Display(state);
}

// 处理按键输入
void Process_Key(CalculatorState* state, KeyPosition key) {
    if (!key.valid) return;
    char key_char = key_map[key.row][key.col];
    // 处理数字键
    if (key_char >= '0' && key_char <= '9') {
        Process_Number(state, key_char - '0');
    }
    // 处理操作符
    else if (key_char == '+' || key_char == '-' || key_char == '*' || key_char == '/') {
        Process_Operator(state, key_char);
    }
    // 处理等号(计算结果)
    else if (key_char == '=') {
        Calculate(state);
    }
    // 处理清除键
    else if (key_char == 'C') {
        Calculator_Init(state);
    }
    // 处理取余键（示例：假设行0列3长按触发取余）
    else if (key.row == 0 && key.col == 3 && key.valid) {
        // 这里可以根据实际需求修改触发方式
        Process_Operator(state, KEY_MOD);
    }
    // 处理整除键（示例：假设行1列3长按触发整除）
    else if (key.row == 1 && key.col == 3 && key.valid) {
        Process_Operator(state, KEY_DIV);
    }
    // 处理退格键（示例：假设行3列0长按触发退格）
    else if (key.row == 3 && key.col == 0 && key.valid) {
        Backspace(state);
    }
    
    Update_OLED_Display(state);
}

// 处理数字输入
void Process_Number(CalculatorState* state, uint8_t number) {
    // 如果已经显示结果，按下数字键则开始新的计算
    if (state->result_displayed) {
        Calculator_Init(state);
    }
    
    // 限制显示长度（防止溢出）
    if (state->display_pos >= 18) return;
    
    // 处理数字输入
    state->display[state->display_pos++] = number + '0';
}

// 处理操作符
void Process_Operator(CalculatorState* state, char op) {
    // 如果已经显示结果，使用结果作为第一个操作数
    if (state->result_displayed) {
        state->num1 = atof(state->display);
        state->result_displayed = false;
    }
    // 如果还没有输入第一个操作数，使用0作为第一个操作数
    else if (state->display_pos == 0) {
        state->num1 = 0;
    }
    // 否则将当前显示的内容转换为第一个操作数
    else {
        state->num1 = atof(state->display);
    }
    
    state->op = op;
    state->op_set = true;
    state->display_pos = 0;
    memset(state->display, 0, sizeof(state->display));
}

// 执行计算
void Calculate(CalculatorState* state) {
    // 如果还没有设置操作符，直接返回
    if (!state->op_set) return;
    
    // 如果还没有输入第二个操作数，使用0作为第二个操作数
    if (state->display_pos == 0) {
        state->num2 = 0;
    }
    // 否则将当前显示的内容转换为第二个操作数
    else {
        state->num2 = atof(state->display);
    }
    
    float result = 0;
    bool error = false;
    
    // 根据操作符进行计算
    switch (state->op) {
        case '+':
            result = state->num1 + state->num2;
            break;
        case '-':
            result = state->num1 - state->num2;
            break;
        case '*':
            result = state->num1 * state->num2;
            break;
        case '/':
            if (state->num2 == 0) {
                error = true;
            } else {
                result = state->num1 / state->num2;
            }
            break;
        case '%':  // 取余运算（仅对整数有效）
            if (state->num2 == 0) {
                error = true;
            } else {
                result = (int)state->num1 % (int)state->num2;
            }
            break;
        case '\\':  // 整除运算（仅对整数有效）
            if (state->num2 == 0) {
                error = true;
            } else {
                result = (int)state->num1 / (int)state->num2;
            }
            break;
        default:
            error = true;
            break;
    }
    
    // 显示结果
    state->display_pos = 0;
    state->op_set = false;
    state->result_displayed = true;
    memset(state->display, 0, sizeof(state->display));
    
    if (error) {
        strcpy(state->display, "Error");
    } else {
        // 格式化结果显示
        if (result == (int)result) {
            // 整数结果
            sprintf(state->display, "%d", (int)result);
        } else {
            // 浮点数结果，保留4位小数
            sprintf(state->display, "%.4f", result);
        }
    }
}

// 退格功能（撤销最后一个输入）
void Backspace(CalculatorState* state) {
    if (state->display_pos > 0) {
        state->display[--state->display_pos] = '\0';
    }
}

// 更新OLED显示
void Update_OLED_Display(CalculatorState* state) {
    OLED_Clear();  // 清屏
    
    // 显示当前输入或结果（第一行）
    OLED_ShowString(1, 1, state->display);
    
    // 显示当前操作符（第二行）
    if (state->op_set) {
        char op_str[3] = {0};
        switch(state->op) {
            case '+': strcpy(op_str, "+"); break;
            case '-': strcpy(op_str, "-"); break;
            case '*': strcpy(op_str, "*"); break;
            case '/': strcpy(op_str, "/"); break;
            case '%': strcpy(op_str, "%"); break;
            case '\\': strcpy(op_str, "//"); break;  // 整除显示为//
            default: break;
        }
        OLED_ShowString(2, 1, op_str);
    }
}

// 毫秒级延时函数（简易实现）
void Delay_ms(uint32_t ms) {
    uint32_t i, j;
    for (i = 0; i < ms; i++)
        for (j = 0; j < 7200; j++);  // 近似1ms延时（根据实际主频调整）
}

// 主函数
int main(void) {
    CalculatorState calc_state;
    KeyPosition key;
    KeyPosition last_key = {0, 0, false};  // 记录上一次按键
    
    // 初始化外设
    SystemInit();          // 系统初始化
    MatrixKey_Init();      // 矩阵键盘初始化
    OLED_Init();           // OLED显示屏初始化
    Calculator_Init(&calc_state);  // 计算器状态初始化
    
    while (1) {
        // 扫描按键
        key = MatrixKey_Scan();
        
        // 按键处理（包含简单去抖）
        if (key.valid) {
            // 检测按键是否变化（防止重复触发）
            if (key.row != last_key.row || key.col != last_key.col) {
                Process_Key(&calc_state, key);
                last_key = key;  // 更新最后按键记录
            }
        } else {
            last_key.valid = false;  // 清除按键记录
        }
        
        Delay_ms(10);  // 主循环延时，降低CPU占用
    }
}